"""
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>

Checks host for open ports

Version .1
Author: Hamzah Ahmed
"""

import socket, sys

def check_userports():
    try:
        remoteServer = input("Enter an IP address to check their ports:\n") #Asks for which host to connect to
        remoteServerIP = socket.gethostbyname(remoteServer)

        test_port = input("Enter a port to scan: \n") #Gives option to quit

        test_port = [int(test_port)]

        for port in test_port:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            result = sock.connect_ex((remoteServerIP, port))
            if result == 0:
                print("Port {}: Open".format(port))
                sock.close()
            else:
                print("Port {}: Closed".format(port))
                sock.close()
        user_input()
    except:
        print("User input error! Please re-enter information in proper format")
        check_userports()


def user_input(): #Asks user if he wants to check custom port in custom host
    print()
    manual_entry = input("Would you like to check a custom port for a specific host of your choice? Enter 'No', or Yes to check ports\n")
    print()
    if manual_entry.upper() == "NO":
        return
    elif manual_entry.upper()== "YES":
        check_userports()
    else:
        print("Please enter either 'Yes' or 'No'")
        user_input()

def port_tester():

    #Checks  IP 172.17.2.87
    print("Scanning ports for 172.17.2.87")
    print("")
    remoteServer = "172.17.2.87" #Saving IP
    remoteServerIP = socket.gethostbyname(remoteServer)

    common = [21, 22, 23, 25, 53, 80, 110, 143]

    for port in common: #Looking through ports in common ports and connecting to it
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        result = sock.connect_ex((remoteServerIP, port))
        if result == 0: #If port is open prints open, else prints closed
            ## if a socket is listening it will print out the port number
            print("Port {}: Open".format(port))
            sock.close()
        else:
            print("Port {}: Closed".format(port))
            sock.close()


    print("")
    print("Scanning ports for 127.0.0.1")
    print("")

    #Checks IP 127.0.0.1
    remoteServer = "127.0.0.1"
    remoteServerIP = socket.gethostbyname(remoteServer)

    common = [21, 22, 23, 25, 53, 80, 110, 143]

    for port in common: #Looking through ports in common ports and connecting to it
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        result = sock.connect_ex((remoteServerIP, port))
        if result == 0: #If port is open prints open, else prints closed
            ## if a socket is listening it will print out the port number
            print("Port {}: Open".format(port))
            sock.close()
        else:
            print("Port {}: Closed".format(port))
            sock.close()
    user_input()

port_tester()